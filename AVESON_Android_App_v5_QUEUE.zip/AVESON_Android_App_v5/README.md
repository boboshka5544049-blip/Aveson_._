# AVESON Android V5

Native Android Java prototype for AVESON.

## V5 changes
- Real Android file picker for audio (`audio/*`)
- Real Android file picker for cover art (`image/*`)
- Selected audio/cover filenames are shown in the Upload screen
- Submit validates release fields and requires both files
- Keeps the stable Java-only build used in V3

## Build
Use GitHub Actions workflow in `.github/workflows/build-apk.yml`.
It builds `:app:assembleDebug` and uploads artifact `AVESON-APK-v4`.

## Important
This version performs local file selection on the device. The selected files are not yet uploaded to the AVESON server. Backend upload/storage comes in the next integration step.
