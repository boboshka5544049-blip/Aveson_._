package com.aveson.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 4101;
    private static final int REQ_COVER = 4102;
    private Uri selectedAudioUri;
    private Uri selectedCoverUri;
    private TextView audioStatus;
    private TextView coverStatus;
    private SharedPreferences prefs;
    private EditText releaseTitleField;
    private EditText artistNameField;
    private EditText genreField;
    private EditText releaseDateField;
    private final int BG = Color.rgb(7, 8, 18);
    private final int SURFACE = Color.rgb(16, 18, 34);
    private final int SURFACE2 = Color.rgb(23, 25, 46);
    private final int PURPLE = Color.rgb(139, 92, 246);
    private final int BLUE = Color.rgb(56, 189, 248);
    private final int WHITE = Color.rgb(248, 249, 255);
    private final int MUTED = Color.rgb(160, 166, 190);
    private final int GREEN = Color.rgb(74, 222, 128);

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs = getSharedPreferences("aveson_data", MODE_PRIVATE);
        showLogin();
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private LinearLayout root() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setBackgroundColor(BG);
        r.setPadding(dp(20), dp(22), dp(20), dp(14));
        return r;
    }

    private TextView tv(String text, float size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextSize(size); v.setTextColor(color);
        v.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        v.setIncludeFontPadding(false);
        return v;
    }

    private GradientDrawable rounded(int color, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radius));
        if (strokeWidth > 0) g.setStroke(dp(strokeWidth), strokeColor);
        return g;
    }

    private LinearLayout.LayoutParams lp(int height, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, height < 0 ? -2 : dp(height));
        p.setMargins(0, dp(top), 0, dp(bottom));
        return p;
    }

    private TextView button(String label, boolean primary, Runnable action) {
        TextView b = tv(label, primary ? 15 : 14, WHITE, true);
        b.setGravity(Gravity.CENTER); b.setPadding(dp(14), dp(13), dp(14), dp(13));
        b.setBackground(rounded(primary ? PURPLE : SURFACE2, 18, Color.rgb(52,55,82), primary ? 0 : 1));
        b.setClickable(true); b.setFocusable(true); b.setOnClickListener(v -> action.run());
        return b;
    }

    private TextView pill(String text, int color) {
        TextView p = tv(text, 11, color, true); p.setGravity(Gravity.CENTER);
        p.setPadding(dp(10), dp(6), dp(10), dp(6));
        p.setBackground(rounded(SURFACE2, 30, 0, 0));
        return p;
    }

    private void showLogin() {
        LinearLayout root = root();
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(0, dp(36), 0, dp(28));
        c.addView(tv("AVESON", 46, PURPLE, true), lp(-1, 30, 8));
        c.addView(tv("Your Music. Your Global Stage.", 20, WHITE, true), lp(-1, 0, 6));
        c.addView(tv("Artist music business — one powerful app.", 14, MUTED, false), lp(-1, 0, 26));

        EditText email = field("Email", false);
        EditText pass = field("Password", true);
        c.addView(email, lp(56, 6, 8)); c.addView(pass, lp(56, 6, 14));
        c.addView(button("SIGN IN", true, () -> showDashboard(false)), lp(-1, 4, 8));
        c.addView(button("DEMO ADMIN", false, () -> showDashboard(true)), lp(-1, 4, 18));
        TextView note = tv("V5 • connected artist → admin queue", 12, MUTED, false); note.setGravity(Gravity.CENTER);
        c.addView(note, lp(-1, 8, 20));
        scroll.addView(c); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
    }

    private EditText field(String hint, boolean password) {
        EditText e = new EditText(this); e.setHint(hint); e.setTextColor(WHITE); e.setHintTextColor(MUTED); e.setTextSize(15);
        e.setSingleLine(true); e.setPadding(dp(16), 0, dp(16), 0);
        if (password) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        e.setBackground(rounded(SURFACE, 16, Color.rgb(48,51,76), 1));
        return e;
    }

    private void showDashboard(boolean admin) {
        LinearLayout root = root();
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout brand = new LinearLayout(this); brand.setOrientation(LinearLayout.VERTICAL);
        brand.addView(tv(admin ? "AVESON ADMIN" : "AVESON", 28, PURPLE, true));
        brand.addView(tv(admin ? "Control Center" : "Artist Dashboard", 14, MUTED, false));
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1f));
        header.addView(pill(admin ? "ADMIN" : "ARTIST", admin ? BLUE : PURPLE));
        root.addView(header, lp(-1, 0, 8));

        ScrollView scroll = new ScrollView(this); LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        c.addView(tv(admin ? "Platform overview" : "Welcome back 👋", 21, WHITE, true), lp(-1, 8, 2));
        c.addView(tv(admin ? "Monitor releases, artists and operations." : "Your music business at a glance.", 13, MUTED, false), lp(-1, 0, 14));
        String[][] metrics = {{"TOTAL STREAMS","128,540"},{"EARNINGS","$1,284.60"},{"ACTIVE RELEASES","12"},{"TOP COUNTRY","Uzbekistan"}};
        for (int i=0;i<metrics.length;i++) c.addView(metric(metrics[i][0], metrics[i][1], i), lp(-1, 5, 7));

        LinearLayout activity = new LinearLayout(this); activity.setOrientation(LinearLayout.VERTICAL); activity.setPadding(dp(16),dp(15),dp(16),dp(15)); activity.setBackground(rounded(SURFACE,20,0,0));
        activity.addView(tv("Recent activity",16,WHITE,true)); activity.addView(tv("Release review queue",13,MUTED,false),lp(-1,8,2)); activity.addView(tv(pendingCount()+" releases waiting for review",14,WHITE,false));
        activity.addView(tv("●  ON TRACK",11,GREEN,true),lp(-1,10,0)); c.addView(activity,lp(-1,12,18));
        scroll.addView(c); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1f));

        LinearLayout nav = new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL); nav.setPadding(0,dp(8),0,0);
        nav.addView(button("HOME",false,()->showDashboard(admin)),navLp());
        nav.addView(button(admin?"QUEUE":"UPLOAD",false,()->{if(admin)showQueue();else showUpload();}),navLp());
        nav.addView(button("PROFILE",false,()->showProfile(admin)),navLp()); root.addView(nav); setContentView(root);
    }

    private LinearLayout.LayoutParams navLp(){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(54),1f); p.setMargins(dp(3),0,dp(3),0); return p; }

    private LinearLayout metric(String title,String value,int index){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(17),dp(15),dp(17),dp(15)); card.setBackground(rounded(SURFACE,20,0,0));
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.addView(tv(title,11,MUTED,true),new LinearLayout.LayoutParams(0,-2,1f)); top.addView(tv(index==0?"+12.4%":"LIVE",10,index==0?GREEN:BLUE,true)); card.addView(top); card.addView(tv(value,26,WHITE,true),lp(-1,8,0)); return card;
    }

    private void showUpload(){
        LinearLayout root=root();
        root.addView(tv("AVESON",28,PURPLE,true),lp(-1,0,2));
        root.addView(tv("Upload Music",21,WHITE,true),lp(-1,4,4));
        root.addView(tv("Prepare your next global release.",13,MUTED,false),lp(-1,0,16));

        ScrollView scroll=new ScrollView(this);
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);

        releaseTitleField=field("Release title",false);
        artistNameField=field("Artist name",false);
        genreField=field("Genre",false);
        releaseDateField=field("Release date",false);
        c.addView(releaseTitleField,lp(-1,56,5,7));
        c.addView(artistNameField,lp(-1,56,5,7));
        c.addView(genreField,lp(-1,56,5,7));
        c.addView(releaseDateField,lp(-1,56,5,7));

        c.addView(button("SELECT AUDIO FILE",true,this::pickAudio),lp(-1,8,4));
        audioStatus=tv("No audio selected",12,MUTED,false);
        c.addView(audioStatus,lp(-1,4,10));

        c.addView(button("SELECT COVER ART",false,this::pickCover),lp(-1,4,4));
        coverStatus=tv("No cover selected",12,MUTED,false);
        c.addView(coverStatus,lp(-1,4,12));

        c.addView(tv("Accepted: MP3/WAV audio + JPG/PNG cover",12,MUTED,false),lp(-1,0,16));
        c.addView(button("SUBMIT FOR REVIEW",true,this::submitRelease),lp(-1,0,20));
        scroll.addView(c);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1f));
        root.addView(button("← BACK TO DASHBOARD",false,()->showDashboard(false)),lp(-1,8,0));
        setContentView(root);
    }

    private void pickAudio(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("audio/*");
        startActivityForResult(i,REQ_AUDIO);
    }

    private void pickCover(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        startActivityForResult(i,REQ_COVER);
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode!=RESULT_OK || data==null || data.getData()==null) return;
        Uri uri=data.getData();
        try { getContentResolver().takePersistableUriPermission(uri,data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION)); }
        catch(Exception ignored) {}
        String name=getFileName(uri);
        if(requestCode==REQ_AUDIO){
            selectedAudioUri=uri;
            if(audioStatus!=null){ audioStatus.setText("✓ Audio: "+name); audioStatus.setTextColor(GREEN); }
            toast("Audio selected");
        } else if(requestCode==REQ_COVER){
            selectedCoverUri=uri;
            if(coverStatus!=null){ coverStatus.setText("✓ Cover: "+name); coverStatus.setTextColor(GREEN); }
            toast("Cover selected");
        }
    }

    private String getFileName(Uri uri){
        String name=null;
        try(Cursor c=getContentResolver().query(uri,null,null,null,null)){
            if(c!=null && c.moveToFirst()){
                int idx=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if(idx>=0) name=c.getString(idx);
            }
        } catch(Exception ignored) {}
        if(name==null) name=uri.getLastPathSegment();
        return name==null ? "selected file" : name;
    }

    private void submitRelease(){
        String title=releaseTitleField==null?"":releaseTitleField.getText().toString().trim();
        String artist=artistNameField==null?"":artistNameField.getText().toString().trim();
        String genre=genreField==null?"":genreField.getText().toString().trim();
        String date=releaseDateField==null?"":releaseDateField.getText().toString().trim();
        if(title.isEmpty() || artist.isEmpty() || genre.isEmpty() || date.isEmpty()){ toast("Please complete all release fields"); return; }
        if(selectedAudioUri==null){ toast("Please select an audio file"); return; }
        if(selectedCoverUri==null){ toast("Please select cover art"); return; }
        try {
            JSONArray arr = getReleases();
            JSONObject r = new JSONObject();
            r.put("title", title);
            r.put("artist", artist);
            r.put("genre", genre);
            r.put("date", date);
            r.put("audio", getFileName(selectedAudioUri));
            r.put("cover", getFileName(selectedCoverUri));
            r.put("status", "Pending Review");
            r.put("created", System.currentTimeMillis());
            arr.put(r);
            prefs.edit().putString("releases", arr.toString()).apply();
            toast("Release submitted for review ✓");
        } catch(Exception e) {
            toast("Could not save release");
        }
    }

    // Overload with a fixed height parameter used by upload fields.
    private LinearLayout.LayoutParams lp(int width, int height, int top, int bottom){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(width,height>0?dp(height):-2); p.setMargins(0,dp(top),0,dp(bottom)); return p; }

    private void showQueue(){
        LinearLayout root=root(); root.addView(tv("AVESON ADMIN",28,PURPLE,true),lp(-1,0,2)); root.addView(tv("Release Queue",21,WHITE,true),lp(-1,4,4)); root.addView(tv("Review incoming artist releases.",13,MUTED,false),lp(-1,0,16));
        ScrollView scroll=new ScrollView(this); LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        try {
            JSONArray arr=getReleases();
            for(int i=arr.length()-1;i>=0;i--){
                JSONObject item=arr.getJSONObject(i);
                c.addView(releaseCard(item, i),lp(-1,5,7));
            }
        } catch(Exception ignored) {}
        String[][] demo={{"Midnight Echoes","Pending Review"},{"Yurak Sadosi","Metadata Check"},{"Global Lights","Pending Review"}};
        for(String[] item:demo){
            LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(16),dp(15),dp(16),dp(15));card.setBackground(rounded(SURFACE,20,0,0));
            LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.addView(tv(item[0],16,WHITE,true),new LinearLayout.LayoutParams(0,-2,1f));r.addView(pill(item[1],item[1].equals("Pending Review")?BLUE:PURPLE));card.addView(r);
            card.addView(tv("Demo artist release • audio + cover",12,MUTED,false),lp(-1,8,0));
            c.addView(card,lp(-1,5,7));
        }
        if(c.getChildCount()==0) c.addView(tv("No releases yet",14,MUTED,false),lp(-1,20,0));
        scroll.addView(c);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1f));root.addView(button("← BACK TO ADMIN",false,()->showDashboard(true)),lp(-1,8,0));setContentView(root);
    }

    private LinearLayout releaseCard(JSONObject item, int index){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(16),dp(15),dp(16),dp(15));card.setBackground(rounded(SURFACE,20,Color.rgb(48,51,76),1));
        String status=item.optString("status","Pending Review");
        LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.addView(tv(item.optString("title","Untitled"),16,WHITE,true),new LinearLayout.LayoutParams(0,-2,1f));r.addView(pill(status,status.equals("Approved")?GREEN:(status.equals("Rejected")?Color.rgb(248,113,113):BLUE)));card.addView(r);
        card.addView(tv(item.optString("artist","Unknown artist")+" • "+item.optString("genre","Genre"),12,MUTED,false),lp(-1,8,0,0));
        card.addView(tv("Release date: "+item.optString("date","—"),12,MUTED,false),lp(-1,5,0,0));
        card.addView(tv("Audio: "+item.optString("audio","—"),11,MUTED,false),lp(-1,5,0,0));
        card.addView(tv("Cover: "+item.optString("cover","—"),11,MUTED,false),lp(-1,2,0,8));
        if(!status.equals("Approved") && !status.equals("Rejected")){
            LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
            actions.addView(button("APPROVE",true,()->updateReleaseStatus(index,"Approved")),new LinearLayout.LayoutParams(0,dp(46),1f));
            actions.addView(button("REJECT",false,()->updateReleaseStatus(index,"Rejected")),new LinearLayout.LayoutParams(0,dp(46),1f));
            cAddMargins(actions); card.addView(actions);
        }
        return card;
    }

    private void cAddMargins(LinearLayout row){
        for(int i=0;i<row.getChildCount();i++){ android.view.View v=row.getChildAt(i); android.view.ViewGroup.MarginLayoutParams m=(android.view.ViewGroup.MarginLayoutParams)v.getLayoutParams(); m.setMargins(i==0?0:dp(6),0,i==row.getChildCount()-1?0:dp(6),0); v.setLayoutParams(m); }
    }

    private JSONArray getReleases(){
        try { return new JSONArray(prefs.getString("releases","[]")); }
        catch(Exception e){ return new JSONArray(); }
    }

    private int pendingCount(){
        int count=0;
        try { JSONArray arr=getReleases(); for(int i=0;i<arr.length();i++){ if(!"Approved".equals(arr.getJSONObject(i).optString("status")) && !"Rejected".equals(arr.getJSONObject(i).optString("status"))) count++; } }
        catch(Exception ignored) {}
        return count;
    }

    private void updateReleaseStatus(int index,String status){
        try { JSONArray arr=getReleases(); if(index>=0 && index<arr.length()){ arr.getJSONObject(index).put("status",status); prefs.edit().putString("releases",arr.toString()).apply(); toast("Release "+status.toLowerCase()+" ✓"); showQueue(); } }
        catch(Exception e){ toast("Could not update release"); }
    }

    private void showProfile(boolean admin){
        LinearLayout root=root();root.addView(tv("AVESON",28,PURPLE,true),lp(-1,0,2));root.addView(tv("Profile",21,WHITE,true),lp(-1,4,4));root.addView(tv(admin?"Administrator":"Artist account",14,MUTED,false),lp(-1,0,18));
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(18),dp(18),dp(18),dp(18));card.setBackground(rounded(SURFACE,20,0,0));card.addView(tv(admin?"AVESON Operations":"Demo Artist",18,WHITE,true));card.addView(tv(admin?"Admin access enabled":"Global artist workspace",13,MUTED,false),lp(-1,8,0));root.addView(card,lp(-1,4,18));root.addView(button("LOG OUT",true,this::showLogin),lp(-1,0,8));root.addView(button("← BACK",false,()->showDashboard(admin)),lp(-1,0,0));setContentView(root);
    }

    private void toast(String message){Toast.makeText(this,message,Toast.LENGTH_SHORT).show();}
}
